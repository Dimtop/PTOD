const ptod = require('./ptod');



ptod('./lp1.txt');